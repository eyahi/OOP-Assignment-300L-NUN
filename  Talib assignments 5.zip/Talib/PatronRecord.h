#ifndef PATRONRECORD_H
#define PATRONRECORD_H

#include <vector>

#include "BookItem.h"

class PatronRecord {
private:
    std::vector<BookItem> checkedOutBooks;

public:
    void addBook(const BookItem& book);
    void removeBook(const BookItem& book);
    const std::vector<BookItem>& getCheckedOutBooks() const;
};

#endif
