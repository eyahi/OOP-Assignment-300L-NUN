#ifndef BOOKITEM_H
#define BOOKITEM_H

#include "LibraryItem.h"
class BookItem : public LibraryItem {
private:
    std::string Author;
    std::string ISBN;

public:
    BookItem(std::string title, bool isCheckedOut, std::string dueDate, std::string author, std::string isbn);

    std::string getAuthor() const;
    std::string getISBN() const;

    void setAuthor(const std::string& newAuthor);
    void setISBN(const std::string& newISBN);

    bool operator==(const BookItem& other) const;
};

#endif

