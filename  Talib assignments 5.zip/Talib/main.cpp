#include "BookItem.h"
#include "Patron.h"
#include "Library.h"

int main(){
    BookItem book1("Object Oriented Programming", true, "15/01/2024", "Talib Jibril", "211203033");
    BookItem book2("Pelican Brief", false, "Not borrowed", "John Grishan", "8567344575233");

    std::cout << "Title: " << book1.getTitle() << '\n' << "Author: " << book1.getAuthor() << '\n' << "ISBN: " << book1.getISBN() << '\n' << std::endl; 
    std::cout << "Title: " << book2.getTitle() << '\n' << "Author: " << book2.getAuthor() << '\n' << "ISBN: " << book2.getISBN() << '\n' << std::endl; 

    std::cout << std::endl;
    Patron patron1("Dr. Ali Emmanuel", "15/01/2024");
    patron1.displayInfo();

    Library library;
    library.addBook(book1);
    library.addBook(book2);

    library.addPatron(patron1);
    library.borrowBook(patron1, book1, "15/01/2024");
    std::cout << '\n';

    std::cout << "Borrowing book\n";
    library.borrowBook(patron1, book1, "15-01-2024");

    const PatronRecord& patron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& patron1CheckedOutBooks = patron1Record.getCheckedOutBooks();

    if (!patron1CheckedOutBooks.empty()) {
        const BookItem& borrowedBook = patron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " borrowed a book:\n";
        std::cout << "Title: " << borrowedBook.getTitle() << '\n';
        std::cout << "Author: " << borrowedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << borrowedBook.getISBN() << '\n';
        std::cout << "Due Date: " << borrowedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " did not borrowed any books.\n";
    }

    std::cout << '\n';

std::cout << '\n' << "Books remaining: "<< std::endl;
for (const auto& book : library.getBooks()) {
    std::cout << "Title: " << book.getTitle() << '\n';
    std::cout << "Author: " << book.getAuthor() << '\n';
    std::cout << "ISBN: " << book.getISBN() << '\n';
    std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
    std::cout << "Due Date: " << book.getDueDate() << '\n';
    std::cout << '\n';
}

    std::cout << "Returned book" << std::endl;
    library.returnBook(patron1, book1);

    const PatronRecord& updatedPatron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& updatedPatron1CheckedOutBooks = updatedPatron1Record.getCheckedOutBooks();

    if (!updatedPatron1CheckedOutBooks.empty()) {
        const BookItem& returnedBook = updatedPatron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " returned the following book:\n";
        std::cout << "Title: " << returnedBook.getTitle() << '\n';
        std::cout << "Author: " << returnedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << returnedBook.getISBN() << '\n';
        std::cout << "Due Date: " << returnedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " did not borrowed any books.\n";
    }

    std::cout << '\n' << "All books" << std::endl;
    for (const auto& book : library.getBooks()) {
        std::cout << "Title: " << book.getTitle() << '\n';
        std::cout << "Author: " << book.getAuthor() << '\n';
        std::cout << "ISBN: " << book.getISBN() << '\n';
        std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
        std::cout << "Due Date: " << book.getDueDate() << '\n';
        std::cout << '\n';
    }

    return 0;
}

