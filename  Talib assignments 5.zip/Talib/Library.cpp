#include "Library.h"
#include "PatronRecord.h"

void Library::addBook(const BookItem& book) {
    books.push_back(book);
}
void Library::addPatron(const Patron& patron) {
    patrons.push_back(patron);
    patronRecords.emplace_back();
}
void Library::borrowBook(const Patron& patron, const BookItem& book, const std::string& dueDate) {
    size_t bookIndex = getBookIndex(book);
    size_t patronIndex = getPatronIndex(patron);

    if (bookIndex != std::numeric_limits<size_t>::max() && patronIndex != std::numeric_limits<size_t>::max()) {
        books[bookIndex].checkOut(dueDate);
        patronRecords[patronIndex].addBook(books[bookIndex]);
    }
}

void Library::returnBook(const Patron& patron, const BookItem& book) {
    size_t bookIndex = getBookIndex(book);
    size_t patronIndex = getPatronIndex(patron);

    if (bookIndex != std::numeric_limits<size_t>::max() && patronIndex != std::numeric_limits<size_t>::max()) {
        books[bookIndex].returnItem();
        patronRecords[patronIndex].removeBook(books[bookIndex]);
    }
}

const PatronRecord& Library::getPatronRecord(const Patron& patron) const {
    size_t index = getPatronIndex(patron);
    return patronRecords[index];
}

const std::vector<BookItem>& Library::getBooks() const {
    return books;
}

size_t Library::getPatronIndex(const Patron& patron) const {
    for (size_t i = 0; i < patrons.size(); ++i) {
        if (patrons[i] == patron) {
            return i;
        }
    }

    return std::numeric_limits<size_t>::max();
}

size_t Library::getBookIndex(const BookItem& book) const {
    for (size_t i = 0; i < books.size(); ++i) {
        if (books[i] == book) {
            return i;
        }
    }
    return std::numeric_limits<size_t>::max();
}
