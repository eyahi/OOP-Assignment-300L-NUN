#ifndef PATRON_RECORD_H
#define PATRON_RECORD_H

#include <vector>
#include <algorithm>
#include "book_item.h"
#include "patron.h"

class PatronRecord
{
private:
    Patron patron;
    std::vector<BookItem> checkedOutBooks;

public:
    // Constructor
    PatronRecord(const Patron& patron) : patron(patron)
    {
    }

    // Functions for managing checked out books
    void addCheckedOutBook(const BookItem& book)
    {
        checkedOutBooks.push_back(book);
    }

    void removeCheckedOutBook(const BookItem& book)
    {
        checkedOutBooks.erase(
            std::remove_if(checkedOutBooks.begin(), checkedOutBooks.end(),
                           [&book](const BookItem& checkedBook)
                           {
                               return checkedBook.getIsbn() == book.getIsbn();
                           }),
            checkedOutBooks.end());
    }

    bool hasCheckedOutBook(const BookItem& book) const
    {
        auto it = std::find_if(checkedOutBooks.begin(), checkedOutBooks.end(),
                               [&book](const BookItem& checkedBook)
                               {
                                   return checkedBook.getIsbn() == book.getIsbn();
                               });

        return it != checkedOutBooks.end();
    }

    const Patron& getPatron() const
    {
        return patron;
    }
};

#endif // PATRON_RECORD_H
