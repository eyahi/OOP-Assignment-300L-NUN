#include "BookItem.h"

BookItem::BookItem(std::string title, bool isCheckedOut, std::string dueDate, std::string author, std::string isbn)
    : LibraryItem(title, isCheckedOut, dueDate), Author(author), ISBN(isbn) {
}

std::string BookItem::getAuthor() const {
    return Author;
}

std::string BookItem::getISBN() const {
    return ISBN;
}

void BookItem::setAuthor(const std::string& newAuthor) {
    Author = newAuthor;
}

void BookItem::setISBN(const std::string& newISBN) {
    ISBN = newISBN;
}

bool BookItem::operator==(const BookItem& other) const {
    return getTitle() == other.getTitle() && Author == other.Author && ISBN == other.ISBN;
}
