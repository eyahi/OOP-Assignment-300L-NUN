#include "Patron.h"
#include <iostream>

// Constructor
Patron::Patron(std::string name, std::string libraryCardNumber)
    : Name(name), LibraryCardNumber(libraryCardNumber) {
}

// Getter methods
std::string Patron::getName() const {
    return Name;
}

std::string Patron::getLibraryCardNumber() const {
    return LibraryCardNumber;
}

// Setter method
void Patron::setName(const std::string& newName) {
    Name = newName;
}

// Equality operator for Patron
bool Patron::operator==(const Patron& other) const {
    return Name == other.Name && LibraryCardNumber == other.LibraryCardNumber;
}

void Patron::setLibraryCardNumber(const std::string& newLibraryCardNumber) {
    LibraryCardNumber = newLibraryCardNumber;
}

// Display information
void Patron::displayInfo() {
    std::cout << "Name of Patron: " << Name << std::endl;
    std::cout << "Library Card Number: " << LibraryCardNumber << std::endl;
}
