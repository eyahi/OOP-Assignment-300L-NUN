#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <algorithm>

class LibraryItem
{
private:
    std::string title;
    bool isCheckedOut;
    std::string dueDate;

public:
    LibraryItem(const std::string &title);
    std::string getTitle() const;
    bool getIsCheckedOut() const;
    std::string getDueDate() const;
    void setTitle(const std::string &title);
    void setDueDate(const std::string &dueDate);
    void checkOut();
    void returnItem();
};

class BookItem : public LibraryItem
{
private:
    std::string author;
    std::string isbn;

public:
    BookItem(const std::string &title, const std::string &author, const std::string &isbn);
    std::string getAuthor() const;
    std::string getIsbn() const;
    void setAuthor(const std::string &author);
    void setIsbn(const std::string &isbn);
    void displayBookInfo() const;
};

class Patron
{
private:
    std::string name;
    int libraryCardNumber;

public:
    Patron(const std::string &name, int libraryCardNumber);
    std::string getName() const;
    int getLibraryCardNumber() const;
    void setName(const std::string &name);
    void setLibraryCardNumber(int libraryCardNumber);
};

class PatronRecord
{
private:
    std::vector<BookItem *> checkedOutBooks;

public:
    void addBook(BookItem *book);
    void removeBook(BookItem *book);
    void displayCheckedOutBooks() const;
};

class Library
{
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

    BookItem *findBookByTitle(const std::string &title);
    Patron *findPatronByCardNumber(int libraryCardNumber);

public:
    void addBook(const std::string &title, const std::string &author, const std::string &isbn);
    void addPatron(const std::string &name, int libraryCardNumber);
    void borrowBook(const std::string &title, int libraryCardNumber);
    void returnBook(const std::string &title, int libraryCardNumber);
    void displayCheckedOutBooks(int libraryCardNumber) const;
};

// Implementations

LibraryItem::LibraryItem(const std::string &title)
    : title(title), isCheckedOut(false), dueDate("Not checked out") {}

std::string LibraryItem::getTitle() const { return title; }

bool LibraryItem::getIsCheckedOut() const { return isCheckedOut; }

std::string LibraryItem::getDueDate() const { return dueDate; }

void LibraryItem::setTitle(const std::string &title) { this->title = title; }

void LibraryItem::setDueDate(const std::string &dueDate) { this->dueDate = dueDate; }

void LibraryItem::checkOut()
{
    if (!isCheckedOut)
    {
        isCheckedOut = true;
        time_t currentTime = time(0);
        time_t dueTime = currentTime + 14 * 24 * 60 * 60; // add 14 days
        dueDate = ctime(&dueTime);
        std::cout << title << " checked out successfully.\n";
    }
    else
    {
        std::cout << title << " is already checked out.\n";
    }
}

void LibraryItem::returnItem()
{
    if (isCheckedOut)
    {
        isCheckedOut = false;
        dueDate = "Not checked out";
        std::cout << title << " returned successfully.\n";
    }
    else
    {
        std::cout << title << " is not checked out.\n";
    }
}

BookItem::BookItem(const std::string &title, const std::string &author, const std::string &isbn)
    : LibraryItem(title), author(author), isbn(isbn) {}

std::string BookItem::getAuthor() const { return author; }

std::string BookItem::getIsbn() const { return isbn; }

void BookItem::setAuthor(const std::string &author) { this->author = author; }

void BookItem::setIsbn(const std::string &isbn) { this->isbn = isbn; }

void BookItem::displayBookInfo() const
{
    std::cout << "Title: " << getTitle() << "\nAuthor: " << author << "\nISBN: " << isbn << "\n";
}

Patron::Patron(const std::string &name, int libraryCardNumber)
    : name(name), libraryCardNumber(libraryCardNumber) {}

std::string Patron::getName() const { return name; }

int Patron::getLibraryCardNumber() const { return libraryCardNumber; }

void Patron::setName(const std::string &name) { this->name = name; }

void Patron::setLibraryCardNumber(int libraryCardNumber) { this->libraryCardNumber = libraryCardNumber; }

void PatronRecord::addBook(BookItem *book) { checkedOutBooks.push_back(book); }

void PatronRecord::removeBook(BookItem *book)
{
    auto it = std::find(checkedOutBooks.begin(), checkedOutBooks.end(), book);
    if (it != checkedOutBooks.end())
    {
        checkedOutBooks.erase(it);
    }
}

void PatronRecord::displayCheckedOutBooks() const
{
    std::cout << "Checked Out Books:\n";
    for (const auto &book : checkedOutBooks)
    {
        std::cout << "- " << book->getTitle() << "\n";
    }
}

void Library::addBook(const std::string &title, const std::string &author, const std::string &isbn)
{
    books.emplace_back(title, author, isbn);
}

void Library::addPatron(const std::string &name, int libraryCardNumber)
{
    patrons.emplace_back(name, libraryCardNumber);
    patronRecords.emplace_back(); // initialize an empty record for the new patron
}

BookItem *Library::findBookByTitle(const std::string &title)
{
    auto it = std::find_if(books.begin(), books.end(),
                           [&](const BookItem &book)
                           { return book.getTitle() == title; });
    return (it != books.end()) ? &(*it) : nullptr;
}

Patron *Library::findPatronByCardNumber(int libraryCardNumber)
{
    auto it = std::find_if(patrons.begin(), patrons.end(),
                           [&](const Patron &patron)
                           { return patron.getLibraryCardNumber() == libraryCardNumber; });
    return (it != patrons.end()) ? &(*it) : nullptr;
}

void Library::borrowBook(const std::string &title, int libraryCardNumber)
{
    BookItem *book = findBookByTitle(title);
    Patron *patron = findPatronByCardNumber(libraryCardNumber);

    if (book && patron)
    {
        if (!book->getIsCheckedOut())
        {
            book->checkOut();
            patronRecords[libraryCardNumber].addBook(book);
            std::cout << "Borrowed successfully.\n";
        }
        else
        {
            std::cout << "Book is already checked out.\n";
        }
    }
    else
    {
        std::cout << "Book or patron not found.\n";
    }
}

void Library::returnBook(const std::string &title, int libraryCardNumber)
{
    BookItem *book = findBookByTitle(title);
    Patron *patron = findPatronByCardNumber(libraryCardNumber);

    if (book && patron)
    {
        if (book->getIsCheckedOut())
        {
            book->returnItem();
            patronRecords[libraryCardNumber].removeBook(book);
            std::cout << "Returned successfully.\n";
        }
        else
        {
            std::cout << "Book is not checked out.\n";
        }
    }
    else
    {
        std::cout << "Book or patron not found.\n";
    }
}

void Library::displayCheckedOutBooks(int libraryCardNumber) const
{
    patronRecords[libraryCardNumber].displayCheckedOutBooks();
}

int main()
{
    Library library;

    library.addBook("OOP", "Emeka Nwokoro", "211203019");
    library.addBook("The Return", "Nenny May", "9780061120084");
    library.addBook("Stranger Things", "Ross Duffer", "9780451524935");

    library.addPatron("Emmanuel Ali", 1524);
    library.addPatron("Jonathan Smith", 1234);

    int option;
    std::string title;
    int libraryCardNumber;

    do
    {
        std::cout << "\nLibrary System Menu:\n";
        std::cout << "1. Borrow a book\n";
        std::cout << "2. Return a book\n";
        std::cout << "3. Display checked out books for a patron\n";
        std::cout << "0. Exit\n";
        std::cout << "Select an option: ";
        std::cin >> option;

        switch (option)
        {
        case 1:
            std::cout << "Enter the title of the book you want to borrow: ";
            std::cin.ignore();
            std::getline(std::cin, title);
            std::cout << "Enter your library card number: ";
            std::cin >> libraryCardNumber;
            library.borrowBook(title, libraryCardNumber);
            break;
        case 2:
            std::cout << "Enter the title of the book you want to return: ";
            std::cin.ignore();
            std::getline(std::cin, title);
            std::cout << "Enter your library card number: ";
            std::cin >> libraryCardNumber;
            library.returnBook(title, libraryCardNumber);
            break;
        case 3:
            std::cout << "Enter your library card number to display checked out books: ";
            std::cin >> libraryCardNumber;
            library.displayCheckedOutBooks(libraryCardNumber);
            break;
        case 0:
            std::cout << "You exited the library. Goodbye!\n";
            break;
        default:
            std::cout << "Invalid input. Please try again.\n";
        }

    } while (option != 0);

    return 0;
}
