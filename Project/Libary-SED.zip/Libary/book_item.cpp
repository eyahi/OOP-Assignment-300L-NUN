#include "book_item.h"

// Constructor
BookItem::BookItem(const std::string& title, const std::string& author, const std::string& isbn)
    : LibraryItem(title), author(author), isbn(isbn) {}

// Getter and setter methods
std::string BookItem::getAuthor() const {
    return author;
}

std::string BookItem::getISBN() const {
    return isbn;
}
void BookItem::checkOut() const {
    // Implement logic to provide information about the checkout status
}
bool BookItem::returnStatus() const {
    return !isCheckedOut;  // Assuming that returnStatus is the opposite of isCheckedOut
}