//BookItem Class

#ifndef BOOK_ITEM_H
#define BOOK_ITEM_H

#include "library_item.h"

class BookItem : public LibraryItem {
private:
    std::string author;
    std::string isbn;
    bool isCheckedOut;

public:
    BookItem(const std::string& title, const std::string& author, const std::string& isbn);
    // Getter and setter methods
    std::string getAuthor() const;
    std::string getISBN() const;
    void checkOut() const;
    bool returnStatus() const;
};

#endif // BOOK_ITEM_H