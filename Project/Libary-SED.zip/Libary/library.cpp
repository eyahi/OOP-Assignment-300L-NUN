#include "library.h"
#include "book_item.h"
#include "patron.h"
#include <algorithm>


// Functions for managing books and patrons, borrowing and returning books

void Library::addBook(const std::string& title, const std::string& author, const std::string& isbn) {
    // Set values based on your requirements
    BookItem newBook(title, author, isbn);
    // ... other initialization as needed ...

    // Call the overloaded addBook function to add the book to the library
    books.push_back(newBook);
}

void Library::addPatron(const std::string& name, const std::string& libraryCardNumber) {
    // Set values based on your requirements
    Patron newPatron(name, libraryCardNumber);
    // ... other initialization as needed ...

    // Call the overloaded addBook function to add the book to the library
    patrons.push_back(newPatron);
    patronRecords.push_back(PatronRecord());
}

void Library::borrowBook(const Patron& patron, const BookItem& book) {
    // Find patron's record
    auto it = std::find(patrons.begin(), patrons.end(), patron);
    if (it != patrons.end()) {
        size_t patronIndex = std::distance(patrons.begin(), it);
        // Borrow the book and update patron's record
        books.push_back(book);
        patronRecords[patronIndex].addBook(book);
        book.checkOut();
    } else {
        // Handle patron not found
    }
}

void Library::returnBook(const Patron& patron, const BookItem& book) {
    // Find patron's record
    auto it = std::find(patrons.begin(), patrons.end(), patron);
    if (it != patrons.end()) {
        size_t patronIndex = std::distance(patrons.begin(), it);
        // Return the book and update patron's record
        auto bookIt = std::find(books.begin(), books.end(), book);
        if (bookIt != books.end()) {
            size_t bookIndex = std::distance(books.begin(), bookIt);
            books.erase(bookIt);
            patronRecords[patronIndex].removeBook(book);
            book.returnItem();
        } else {
            // Handle book not found in the library
        }
    } else {
        // Handle patron not found
    }
}
