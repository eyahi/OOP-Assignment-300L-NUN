#include "library.h"
#include "book_item.h"
#include "patron.h"

int main(){
Library myLibrary;

// my book
BookItem myBook("Introduction to C++", "SEDOOTER YANMAR-ORTESE", "211203032");
myLibrary.addBook("myBook","SED","123");

// Lecturer as a patron
Patron lecturer("DR. EMMANUEL ALI", "15012024");
myLibrary.addPatron("lecturer", "20");

return 0;
}