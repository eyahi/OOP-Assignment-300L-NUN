#include "library_item.h"

// Constructor
LibraryItem::LibraryItem(const std::string& title)
    : title(title), isCheckedOut(false), dueDate("") {}

// Getter and setter methods
std::string LibraryItem::getTitle() const {
    return title;
}

bool LibraryItem::isChecked() const {
    return isCheckedOut;
}

std::string LibraryItem::getDueDate() const {
    return dueDate;
}

void LibraryItem::setTitle(const std::string& newTitle) {
    title = newTitle;
}

// checkOut and returnItem methods
void LibraryItem::checkOut() {
    if (!isCheckedOut) {
        isCheckedOut = true;
        // Set dueDate based on your logic, e.g., current date + some duration
    } else {
        // Handle already checked out scenario
    }
}

void LibraryItem::returnItem() {
    if (isCheckedOut) {
        isCheckedOut = false;
        dueDate = "";  // Reset dueDate
    } else {
        // Handle already returned scenario
    }
}