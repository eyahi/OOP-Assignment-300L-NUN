//LibraryItem Class

#ifndef LIBRARY_ITEM_H
#define LIBRARY_ITEM_H

#include <string>

class LibraryItem {
private:
    std::string title;
    bool isCheckedOut;
    std::string dueDate;
bool returnitem;

public:
    LibraryItem(const std::string& title);
    // Getter and setter methods
    std::string getTitle() const;
    bool isChecked() const;
    std::string getDueDate() const;
    bool returnItem() const;

    // Setter methods
    void setTitle(const std::string& newTitle);





    void checkOut();
    void returnItem();
};

#endif // LIBRARY_ITEM_H