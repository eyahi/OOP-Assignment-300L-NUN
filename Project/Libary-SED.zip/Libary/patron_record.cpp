#include "patron_record.h"
#include <algorithm> // Include the algorithm header for std::remove

// Functions for managing checked out books
void PatronRecord::addBook(const BookItem& book) {
    checkedOutBooks.push_back(book);
}

void PatronRecord::removeBook(const BookItem& book) {
    // Remove the book from the record (assuming each book is unique in the record)
    auto it = std::remove(checkedOutBooks.begin(), checkedOutBooks.end(), book);
    checkedOutBooks.erase(it, checkedOutBooks.end());
}