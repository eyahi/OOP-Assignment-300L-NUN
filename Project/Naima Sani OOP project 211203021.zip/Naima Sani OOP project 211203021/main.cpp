#include "library.h"
#include <iostream>

int main()
{
    BookItem book1("Object Oriented Programming", "Naima Sani Abubakar", "211203021");

    Patron patron1("Dr. Ali", "15/04/2024");

    Library library;

    library.addBook(book1);

    library.addPatron(patron1);

    library.borrowBook(patron1, book1);

    library.borrowBook(patron1, book1);

    library.returnBook(patron1, book1);

    return 0;
}
