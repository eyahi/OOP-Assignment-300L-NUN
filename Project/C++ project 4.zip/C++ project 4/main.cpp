#include <iostream>
#include "BookItem.h"
#include "Patron.h"
#include "PatronRecord.h"
#include "Library.h"

int main() {
    // Create a Library instance
    Library myLibrary;

    // Create and add books to the library
    BookItem book1("Computer Engineering", "Victor James", "211203043");
    BookItem book2("The Great Gatsby", "F. Scott Fitzgerald", "123456789");
    std::cout << "Adding books to the library..." << std::endl;
    myLibrary.addBook(book1);
    myLibrary.addBook(book2);

// Create a PatronRecord for Dr. Emmanuel Ali
    PatronRecord lecturerRecord;
    int lecturerCardNumber = 20240109; // Example: use a unique number or date
    std::cout << "Adding Dr. Emmanuel Ali (PhD) as a patron to the library..." << std::endl;
    myLibrary.addPatron(lecturerCardNumber, lecturerRecord);


    // Borrow a book
    std::cout << "Attempting to borrow 'Computer Engineering'..." << std::endl;
    if (myLibrary.borrowBook(1, "211203043")) {
        std::cout << "Book borrowed successfully." << std::endl;
    } else {
        std::cout << "Book borrowing failed." << std::endl;
    }

    // Return a book
    std::cout << "Attempting to return 'Computer Engineering'..." << std::endl;
    if (myLibrary.returnBook(1, "211203043")) {
        std::cout << "Book returned successfully." << std::endl;
    } else {
        std::cout << "Book return failed." << std::endl;
    }

    return 0;
}