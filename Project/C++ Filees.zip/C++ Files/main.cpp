#include "BookItem.h"
#include "Patron.h"
#include "Library.h"

int main(){
    BookItem book1("Object Oriented Programming", true, "15-01-2024", "Ahmadu Silas", "211203008");
    BookItem book2("Object Oriented Programming Vol 2", false, "Not borrowed", "Ahmed Aliyu", "978-0-06-112008-4");

    std::cout << "Title of First Book: " << book1.getTitle() << std::endl; 
    std::cout << "Author: " << book1.getAuthor() << std::endl; 
    std::cout << "International Standard Book Number (ISBN): " << book1.getISBN() << '\n' << std::endl;

    std::cout << "Title of Second Book: " << book2.getTitle() << std::endl; 
    std::cout << "Author: " << book2.getAuthor() << std::endl; 
    std::cout << "International Standard Book Number (ISBN): " << book2.getISBN() << '\n' << std::endl;

    
    std::cout << std::endl;
    Patron patron1("Engr. Ali Emmanuel", "15-01-2024");
    
    patron1.displayInfo();


    Library library;
    library.addBook(book1);
    library.addBook(book2);

    library.addPatron(patron1);

    library.borrowBook(patron1, book1, "2023-01-01");

    std::cout << '\n';

    // Borrow a book and display information
    std::cout << "Borrowed Books...\n";
    library.borrowBook(patron1, book1, "15-01-2024");

    const PatronRecord& patron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& patron1CheckedOutBooks = patron1Record.getCheckedOutBooks();

    if (!patron1CheckedOutBooks.empty()) {
        const BookItem& borrowedBook = patron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " has borrowed a book:\n";
        std::cout << "Title: " << borrowedBook.getTitle() << '\n';
        std::cout << "Author: " << borrowedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << borrowedBook.getISBN() << '\n';
        std::cout << "Due Date: " << borrowedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " has not borrowed any books.\n";
    }

    std::cout << '\n';

    // Display remaining books after one is borrowed
std::cout << '\n' << "Remaining Books after Borrowing: \n";
for (const auto& book : library.getBooks()) {
    std::cout << "Title: " << book.getTitle() << '\n';
    std::cout << "Author: " << book.getAuthor() << '\n';
    std::cout << "ISBN: " << book.getISBN() << '\n';
    std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
    std::cout << "Due Date: " << book.getDueDate() << '\n';
    std::cout << '\n';
}

    // Return the book and display updated information
    std::cout << "Returned Books...\n";
    library.returnBook(patron1, book1);

    const PatronRecord& updatedPatron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& updatedPatron1CheckedOutBooks = updatedPatron1Record.getCheckedOutBooks();

    if (!updatedPatron1CheckedOutBooks.empty()) {
        const BookItem& returnedBook = updatedPatron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " has returned the following book:\n";
        std::cout << "Title: " << returnedBook.getTitle() << '\n';
        std::cout << "Author: " << returnedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << returnedBook.getISBN() << '\n';
        std::cout << "Due Date: " << returnedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " has not borrowed any books.\n";
    }

    // Display remaining books after one is Returned
    std::cout << '\n' << "Remaining Books after Borrowing:\n";
    for (const auto& book : library.getBooks()) {
        std::cout << "Title: " << book.getTitle() << '\n';
        std::cout << "Author: " << book.getAuthor() << '\n';
        std::cout << "ISBN: " << book.getISBN() << '\n';
        std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
        std::cout << "Due Date: " << book.getDueDate() << '\n';
        std::cout << '\n';
    }

    return 0;
}

