#include "Book.h"
#include <iostream>

// Constructor
Book::Book(std::string title, std::string author, int isbn)
    : Title(title), Author(author), ISBN(isbn) {
}

// Getter methods
std::string Book::getTitle() const {
    return Title;
}

std::string Book::getAuthor() const {
    return Author;
}

int Book::getISBN() const {
    return ISBN;
}

// Setter methods
void Book::setTitle(const std::string& newTitle) {
    Title = newTitle;
}

void Book::setAuthor(const std::string& newAuthor) {
    Author = newAuthor;
}

void Book::setISBN(int newISBN) {
    ISBN = newISBN;
}

// Display information
void Book::displayInfo() {
    std::cout << "Title of Book: " << Title << std::endl;
    std::cout << "Author: " << Author << std::endl;
    std::cout << "International Standard Book Number (ISBN): " << ISBN << std::endl;
}
