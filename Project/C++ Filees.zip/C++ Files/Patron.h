#ifndef PATRON_H
#define PATRON_H

#include <iostream>
#include <string>

class Patron {
private:
    std::string Name;
    std::string LibraryCardNumber;

public:
    // Constructors
    Patron(std::string name, std::string libraryCardNumber);

    // Getter methods to access private data
    std::string getName() const;
    std::string getLibraryCardNumber() const;

    // Setter methods to modify private data
    void setName(const std::string& newName);
    void setLibraryCardNumber(const std::string& newLibraryCardNumber);

    // Equality operator for Patron
    bool operator==(const Patron& other) const;

    // Display patron information
    void displayInfo();
};
#endif
