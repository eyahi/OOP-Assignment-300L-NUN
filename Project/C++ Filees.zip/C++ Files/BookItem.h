#ifndef BOOKITEM_H
#define BOOKITEM_H

#include "LibraryItem.h"

class BookItem : public LibraryItem {
private:
    std::string Author;
    std::string ISBN;

public:
    // Constructor
    BookItem(std::string title, bool isCheckedOut, std::string dueDate, std::string author, std::string isbn);

    // Getters
    std::string getAuthor() const;
    std::string getISBN() const;

    // Setters
    void setAuthor(const std::string& newAuthor);
    void setISBN(const std::string& newISBN);

    // Equality operator
    bool operator==(const BookItem& other) const;
};

#endif

