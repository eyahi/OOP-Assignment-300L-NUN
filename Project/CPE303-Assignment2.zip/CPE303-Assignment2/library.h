#ifndef LIBRARY_H
#define LIBRARY_H

#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <chrono>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <iomanip>

#ifdef _WIN32
    #include <windows.h>
#endif

#include "bookItem.h"
#include "patron.h"
#include "patronRecord.h"

class Library {
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:
    void addBook(std::string author, std::string isbn, std::string title) {
        books.push_back(BookItem(author, isbn, title, false, ""));
        std::cout << "Book Successfully Added.\n" << std::endl;
    }

    void addPatron(std::string name, std::string libraryCardNumber) {
        patrons.push_back(Patron(name, libraryCardNumber));
        std::cout << "Patron Successfully Added.\n" << std::endl;
    }

    void disBooks(){
        if (books.size() == 0){
            std::cout << "No Books Yet\n" << std::endl;
        }
        else {
            for (int i = 0; i < books.size(); i++){
                std::cout << "Title: " << books[i].getTitle() << std::endl;
                std::cout << "Author: " << books[i].getAuthor() << std::endl;
                std::cout << "ISBN: " << books[i].getIsbn() << std::endl;
                std::cout << "Is Available? " << std::boolalpha << !(books[i].getIsCheckedOut()) << "\n" << std::endl;
            }
        }
    }

    void disPatrons(){
        if (patrons.size() == 0) {
            std::cout << "No Patrons Yet\n" << std::endl;
        }
        else {
            for (int i = 0; i < patrons.size(); i++){
                std::cout << "Name: " << patrons[i].getName() << std::endl;
                std::cout << "Library Card Number: " << patrons[i].getLibraryCardNumber() << "\n" << std::endl;
            }
        }
    }

    void disPatronRecords(){
        if (patronRecords.size() == 0){
            std::cout << "No Records Yet\n" << std::endl;
        }
        else {
            for (int i = 0; i < patronRecords.size(); i++){
                std::cout << "Date: " << patronRecords[i].getDate() << std::endl;
                std::cout << "Name: " << patronRecords[i].getName() << std::endl;
                std::cout << "Library Card Number: " << patronRecords[i].getLibraryCardNumber() << std::endl;
                std::cout << "Title: " << patronRecords[i].getTitle() << std::endl;
                std::cout << "Author: " << patronRecords[i].getAuthor() << std::endl;
                std::cout << "ISBN: " << patronRecords[i].getIsbn() << std::endl;
                std::cout << "Date Due: " << patronRecords[i].getDueDate() << std::endl;
                std::cout << "Is Returned? " << std::boolalpha << !(patronRecords[i].getIsCheckedOut()) << "\n" << std::endl;
            }  
        }
    }

    void checkOut(std::string name, std::string libraryCardNumber, std::string author, std::string isbn, std::string title){
        if (patrons.size() == 0) {
            std::cout << "Sorry, No Books for Today. Come back Tomorrow. New Patrons Please Sign UP and Get Your Library Number Today.\n" << std::endl;
        }
        else {
            int j = 0, k = 0;
            for (int i = 0; i < patrons.size(); i++){
                if (patrons[i].getName() == name){
                    j = 1;
                }
                if (patrons[i].getLibraryCardNumber() == libraryCardNumber){
                    k = 1;
                }
            }
    
            for (int i = 0; i < books.size(); i++){
                if ((j+k) == 2){
                    if (books[i].getTitle() == title){
                        if (books[i].getIsCheckedOut() == false){
                            auto newTime = std::chrono::system_clock::now() + std::chrono::hours(168); //modify this for appropriate time
                            std::time_t time = std::chrono::system_clock::to_time_t(newTime);
                            std::stringstream formattedDate;
                            formattedDate << std::put_time(std::localtime(&time), "%Y-%m-%d");
                            std::string dueDate = formattedDate.str();

                            auto newTime2 = std::chrono::system_clock::now();
                            std::time_t time2 = std::chrono::system_clock::to_time_t(newTime2);
                            std::stringstream formattedDate2;
                            formattedDate2 << std::put_time(std::localtime(&time2), "%Y-%m-%d");
                            std::string date = formattedDate2.str();

                            patronRecords.push_back(PatronRecord(name, libraryCardNumber, author, isbn, title, dueDate, true, date));
                            books[i].setIscheckedOut(true);
                            std::cout << "Book Successfully Checked Out. Enjoy your Book.\n" << std::endl;
                            break;
                        }
                        else {
                            std::cout << "Book Has Already been Checked Out. Try Out Another Book.\n" << std::endl;
                            break;
                        }   
                    }
                    else {
                        if (i == (books.size() - 1)) {
                            std::string response2;
                            std::cout << "Book Not In Selection. Get Book Online? (Y/N) ";
                            std::getline(std::cin, response2);
                            std::cout << "" << std::endl;
                            if (response2 == "Y" || response2 == "y") {
                                for (int i = 0; i < title.size(); i++){
                                    if (title[i] == ' '){
                                        title[i] = '+';
                                    }
                                }
                                for (int i = 0; i < author.size(); i++){
                                    if (author[i] == ' '){
                                        author[i] = '+';
                                    }
                                }
                                std::string url = "start https://www.google.com/search?q=" + title + "+book+by+" + author;
                                #ifdef _WIN32
                                    system(url.c_str());
                                    break;
                                #else
                                    // Assuming non-Windows OS
                                    std::cout << "Sorry You can't go online. This code was tailor-made for Windows OS.\n" << std::endl;
                                    break;
                                #endif
                            }
                        }
                    }
                }
                else {
                    std::cout << "Patron Not Enrolled in System. Sign Up Today for your Library card Number.\n" << std::endl;
                    break;
                }
            }     
        }
    }

    void returnItem(std::string title, std::string libraryNumber){
        if (patronRecords.size() == 0) {
            std::cout << "No Books Have been Checked Out.\n" << std::endl;
        }
        else {
            for (int i = 0; i < books.size(); i++){
                if(books[i].getTitle() == title) {
                    books[i].setIscheckedOut(false);
                }
            }
            
            for (int i = 0; i < patronRecords.size(); i++){
                if (patronRecords[i].getTitle() == title && patronRecords[i].getLibraryCardNumber() == libraryNumber) {
                    patronRecords[i].setIscheckedOut(false);
                    auto currentTime = std::chrono::system_clock::now();
                    std::tm tm = {};
                    std::istringstream dateStream(patronRecords[i].getDueDate());
                    dateStream >> std::get_time(&tm, "%Y-%m-%d");
                    auto datePoint = std::chrono::system_clock::from_time_t(std::mktime(&tm));

                    if (currentTime > datePoint){
                        std::cout << "Book Successfully Returned. Please Pay the late fee.\n" << std::endl;
                        break;
                    }
                    else{
                        std::cout << "Book Successfully Returned. Please Come Again.\n" << std::endl;
                        break;
                    }
                }
                else {
                    std::cout << "Invalid Book or Library Card Number. Please Check your inputs.\n" << std::endl;
                    break;
                }
            }
        }
    }

    bool booksToReturn(){
        if (patronRecords.size() == 0){
           return false;
        }
        else {
            for (int i = 0; i < patronRecords.size(); i++){
                if (patronRecords[i].getIsCheckedOut()){
                    return true;
                }
            }

            if (i == (patronRecords.size() - 1)){
                return false;
            }  
        }
    }

    bool canCheckOut(){
        if (patrons.size() == 0){
           return false;
        }
        else {
            return true;
        }
    }
};

#endif