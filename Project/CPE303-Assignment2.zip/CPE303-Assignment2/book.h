#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    // Book attributes
    std::string Title;
    std::string Author;
    std::string Isbn;

public:
    // getter function
    std::string getTitle() { return Title; }
    std::string getAuthor() { return Author;}
    std::string getIsbn() { return Isbn; }

    // setter functions
    void setTitle(std::string title) { Title = title; }
    void setAuthor(std::string author) { Author = author; }
    void setIsbn(std::string isbn) { Isbn = isbn; }

    // Book constructor
    Book(std::string title, std::string author, std::string isbn) : Title(title), Author(author), Isbn(isbn) {}
};
    
#endif