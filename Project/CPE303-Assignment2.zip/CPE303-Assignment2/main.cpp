#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <limits>
#include <stdexcept>

#include "library.h"

int convertToInteger(const std::string& input) {
    try {
        int convertedValue = std::stoi(input);

        // Additional validation
        if (convertedValue < 0 || convertedValue > 7) {
            throw std::out_of_range("");
        }

        return convertedValue;
    } catch (const std::invalid_argument& e) {
        throw std::invalid_argument("Please Enter a Valid Command.");
    } catch (const std::out_of_range& e) {
        throw std::out_of_range("Please Enter a Valid Command.");
    }
}

int main() {

    Library bibliotheqa;
    
    std::string input;
    int validInput;

    //you can only borrow the books that are available
    //if book not in selection then put isbn as 000
    //The first book containing my Name, ID, Course
    //The first patron is the lecturer
    std::cout << "\nRunning Code With Basic Requirements.............................................." << std::endl;

    std::cout << "Adding a Book..................." << std::endl;
    bibliotheqa.addBook("Ikeamaka Collins Chidubem", "211103054", "CPE303 - Object Oriented Programming");

    std::cout << "Adding a Patron................." << std::endl;
    bibliotheqa.addPatron("Dr. Emmanuel Ali", "2024-1-16");

    std::cout << "Borrowing a Book................" << std::endl;
    bibliotheqa.checkOut("Dr. Emmanuel Ali", "2024-1-16", "Ikeamaka Collins Chidubem", "211103054", "CPE303 - Object Oriented Programming");

    std::cout << "Returning a Book................" << std::endl;
    bibliotheqa.returnItem("CPE303 - Object Oriented Programming", "2024-1-16");

    //Other methods are .disBooks() .disPatrons() .disPatronRecords()
    //This is my own added functionality
    //I tried making a User Interface that can accept user input to manage the library
    std::cout << "\n\nRunning Code With Added Functionality.............................................\n********************************************************************************** " << std::endl;
    std::cout << "\n***********      Welcome To Bibliotheqa Library Management System      ***********" << std::endl;
    std::cout << "\n********************************************************************************** \n" << std::endl;

    while (true) {
        try {
            std::cout << "These are your Commands (Enter a Number for The Corresponding Command)\n1. AddBook()\n2. AddPatron()\n3. CheckOut()\n4. ReturnItem()\n5. Print Book List\n6. Print Patron List\n7. Print Patron Records\n0. Exit()\n\n*********************************************************************************\n>> What do you want to do? ";
            std::getline(std::cin, input);
            validInput = convertToInteger(input);
            break;

        } catch (const std::exception& e) {
            std::cerr << e.what() << std::endl;
        }
    }

    while (validInput != 0) {
        if (validInput == 1) {
            std::string title, author, isbn;

            std::cout << "Enter Book Title: ";
            std::getline(std::cin, title);
            std::cout << "Enter Book Author: ";
            std::getline(std::cin, author);
            std::cout << "Enter Book ISBN: ";
            std::getline(std::cin, isbn);

            bibliotheqa.addBook(author, isbn, title);
            std::cout << "********************************************************************************* \n" << std::endl;
        }
        else if (validInput == 2) {
            std::string name;
            std::string libraryCardNumber;

            std::cout << "Enter Patron Name: ";
            std::getline(std::cin, name);
            std::cout << "Enter Patron Library Card Number: ";
            std::getline(std::cin, libraryCardNumber);

            bibliotheqa.addPatron(name, libraryCardNumber);
            std::cout << "********************************************************************************* \n" << std::endl;
        }
        else if (validInput == 3) {
            bibliotheqa.canCheckOut();
            if (bibliotheqa.canCheckOut() == true){
                std::string name;
                std::string libraryCardNumber;
                std::string author;
                std::string isbn;
                std::string title;

                std::cout << "Enter Patron Name: ";
                std::getline(std::cin, name);
                std::cout << "Enter Patron Library Card Number: ";
                std::getline(std::cin, libraryCardNumber);
                std::cout << "Enter Book Author: ";
                std::getline(std::cin, author);
                std::cout << "Enter Book ISBN: ";
                std::getline(std::cin, isbn);
                std::cout << "Enter Book Title: ";
                std::getline(std::cin, title);

                bibliotheqa.checkOut(name, libraryCardNumber, author, isbn, title);
                std::cout << "********************************************************************************* \n" << std::endl;
            }
            else {
                std::cout << "No Patrons Available. New Patrons Sign Up and Get Your Library Number Today.\n" << std::endl;
                std::cout << "********************************************************************************* \n" << std::endl;
            }
            
            
        }
        else if (validInput == 4) {
            bibliotheqa.booksToReturn();
            if (bibliotheqa.booksToReturn() == true){
                std::string bookTitle;
                std::string libraryNumber;

                std::cout << "Enter Book Title to Return: ";
                std::getline(std::cin, bookTitle);
                std::cout << "Enter Library Card Number: ";
                std::getline(std::cin, libraryNumber);
        
                bibliotheqa.returnItem(bookTitle, libraryNumber);
                std::cout << "********************************************************************************* \n" << std::endl;
            }
            else {
                std::cout << "No Books Have been Checked Out.\n" << std::endl;
                std::cout << "********************************************************************************* \n" << std::endl;
            }
        }
        else if (validInput == 5){
            bibliotheqa.disBooks();
            std::cout << "********************************************************************************* \n" << std::endl;
        }
        else if (validInput == 6){
            bibliotheqa.disPatrons();
            std::cout << "********************************************************************************* \n" << std::endl;
        }
        else if (validInput == 7){
            bibliotheqa.disPatronRecords();
            std::cout << "********************************************************************************* \n" << std::endl;
        }
        std::cout << ">> Anything else?" << std::endl;
        while (true) {
            try {
                std::cout << "These are your Commands (Enter a Number for The Corresponding Command)\n1. AddBook()\n2. AddPatron()\n3. CheckOut()\n4. ReturnItem()\n5. Print Book List\n6. Print Patron List\n7. Print Patron Records\n0. Exit()\n\n*********************************************************************************\n>> What do you want to do? ";
                std::getline(std::cin, input);
                validInput = convertToInteger(input);
                break;
            } catch (const std::exception& e) {
                std::cerr << "Error: " << e.what() << std::endl;
            }
        }
    }

    std::cout << "\nGoodbye. Thank you for Using This Service.\n" << std::endl;

    system("pause");
    
    return 0;
}