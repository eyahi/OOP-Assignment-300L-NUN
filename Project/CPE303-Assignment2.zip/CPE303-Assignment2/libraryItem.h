#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <string>

class LibraryItem {
private:
    // LibraryItem attributes
    std::string Title;
    bool IsCheckedOut = false;
    std::string DueDate;

public:
    // getter functions
    std::string getTitle() { return Title; }
    bool getIsCheckedOut() { return IsCheckedOut; }
    std::string getDueDate() { return DueDate; }

    //setter functions
    void setTitle(std::string title) { Title = title; }
    void setIscheckedOut(bool isCheckedOut) { IsCheckedOut = isCheckedOut; }
    void setDueDate(std::string dueDate) { DueDate = dueDate; }

    //checkOut() and returnItem() functions
    void checkOut() { IsCheckedOut = true; }
    void returnItem() { IsCheckedOut = false; }

    // LibraryItem constructor
    LibraryItem(std::string title, bool isCheckedOut, std::string duedate) : Title(title), IsCheckedOut(isCheckedOut), DueDate(duedate) {}
};

#endif