#ifndef PATRONRECORD_H
#define PATRONRECORD_H

#include <string>

#include "bookItem.h"
#include "patron.h"

class PatronRecord : public Patron, public BookItem {
private:
    std::string Date;
public:
    std::string getDate() { return Date; }
    PatronRecord(std::string name, std::string libraryCardNumber, std::string author, std::string isbn, std::string title, std::string dueDate, bool isCheckedOut, std::string date) : Patron(name, libraryCardNumber), BookItem(author, isbn, title, isCheckedOut, dueDate), Date(date) {}
};

#endif