#ifndef PATRON_H
#define PATRON_H

#include <string>

class Patron {
private:
    // Patron attributes
    std::string Name;
    std::string LibraryCardNumber;

public:
    // getter functions
    std::string getName() { return Name; }
    std::string getLibraryCardNumber() { return LibraryCardNumber; }

    // setter functions
    void setName(std::string name) { Name = name; }
    void setLibraryCardNumber(std::string libraryCardNumber) { LibraryCardNumber = libraryCardNumber; }

    // Patron constructor
    Patron(std::string name, std::string libraryCardNumber) : Name(name), LibraryCardNumber(libraryCardNumber) {}
};

#endif