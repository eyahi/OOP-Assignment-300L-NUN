#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <iomanip>

// Use iomanip for formatting output
using namespace std::iomanip;

// LibraryItem Class
class LibraryItem {
private:
    std::string title;
    bool isCheckedOut;
    std::string dueDate;

public:
    LibraryItem(std::string t, bool status, std::string due) : title(t), isCheckedOut(status), dueDate(due) {}
    void checkOut() { isCheckedOut = true; }
    void returnItem() { isCheckedOut = false; }
    bool getStatus() const { return isCheckedOut; }
    std::string getTitle() const { return title; }
    std::string getDueDate() const { return dueDate; }
    void setDueDate(std::string date) { dueDate = date; }
};

// Book Class
class Book : public LibraryItem {
private:
    std::string author;
    std::string isbn;

public:
    Book(std::string t, std::string a, std::string i, bool status, std::string due) : LibraryItem(t, status, due), author(a), isbn(i) {}
    std::string getAuthor() const { return author; }
    std::string getISBN() const { return isbn; }
};

// Patron Class
class Patron {
private:
    std::string name;
    std::string libraryCardNumber;

public:
    Patron(std::string n, std::string cardNo) : name(n), libraryCardNumber(cardNo) {}
    std::string getName() const { return name; }
    std::string getLibraryCardNumber() const { return libraryCardNumber; }
};

// PatronRecord Class
class PatronRecord {
private:
    std::map<std::string, Book> checkedOutBooks; // Use map for faster title lookup
    Patron patron;

public:
    PatronRecord(Patron p) : patron(p) {}
    void addBook(Book book) { checkedOutBooks[book.getTitle()] = book; }
    void removeBook(std::string title) { checkedOutBooks.erase(title); }
    std::vector<Book> getCheckedOutBooks() const {
        std::vector<Book> books;
        for (auto const& [title, book] : checkedOutBooks) {
            books.push_back(book);
        }
        return books;
    }
    std::string getPatronName() const { return patron.getName(); }
};

// Library Class
class Library {
private:
    std::vector<Book> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:
    void addBook(Book book) { books.push_back(book); }
    void addPatron(Patron patron) { patrons.push_back(patron); patronRecords.push_back(PatronRecord(patron)); }
    bool borrowBook(std::string bookTitle, std::string patronName, std::string dueDate) {
        for (auto& book : books) {
            if (book.getTitle() == bookTitle && !book.getStatus()) {
                for (auto& record : patronRecords) {
                    if (record.getPatronName() == patronName) {
                        book.checkOut();
                        record.addBook(Book(bookTitle, book.getAuthor(), book.getISBN(), true, dueDate));
                        return true;
                    }
                }
            }
        }
        return false; // Book not found, not available, or patron not found
    }
    bool returnBook(std::string bookTitle, std::string patronName) {
        for (auto& record : patronRecords) {
            if (record.getPatronName() == patronName) {
                auto it = record.checkedOutBooks.find(bookTitle);
                if (it != record.checkedOutBooks.end()) {
                    it->second.returnItem();
                    record.removeBook(bookTitle);
                    return true;
                }
            }
        }
        return false; // Book not found in patron's record
    }
    void displayCatalog() const {
        std::cout << "*** Library Catalog ***" << std::endl;
void Library::displayCatalog() const {
    std::cout << "*** Library Catalog ***" << std::endl;
    std::cout << std::setw(25) << "Title" << std::setw(25) << "Author" << std::setw(15) << "ISBN" << std::setw(15) << "Available" << std::endl;
    std::cout << std::setw(80) << std::setfill('-') << "" << std::endl;
    for (const Book& book : books) {
        std::cout << std::setw(25) << book.getTitle() << std::setw(25) << book.getAuthor() << std::setw(15) << book.getISBN() << std::setw(15) << (book.getStatus() ? "Yes" : "No") << std::endl;
    }
}

int main() {
    Library library;

    // Add some books and patrons to the library (example data)
    library.addBook(Book("The Lord of the Rings", "J.R.R. Tolkien", "1234567890", false, ""));
    library.addBook(Book("The Hitchhiker's Guide to the Galaxy", "Douglas Adams", "9876543210", true, "2024-02-15"));
    library.addPatron(Patron("Dr Emanuel Ali", "1234"));
    library.addPatron(Patron("Achonmakai Dankaro", "16012024"));

    // Menu-driven interface (example)
    int choice;
    do {
        std::cout << "\nLibrary Management System" << std::endl;
        std::cout << "1. Borrow Book" << std::endl;
        std::cout << "2. Return Book" << std::endl;
        std::cout << "3. View Catalog" << std::endl;
        std::cout << "4. View Patron's Checked-Out Books" << std::endl;
        // ... (Add more options as needed)
        std::cout << "0. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        // Implement actions based on choices (using library functions)
        // ...

    } while (choice != 0);

    return 0;
}
