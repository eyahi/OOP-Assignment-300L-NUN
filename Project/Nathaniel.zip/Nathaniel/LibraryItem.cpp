#include "LibraryItem.h"
LibraryItem::LibraryItem(std::string title, bool ischeckedout, std::string duedate)
    : Title(title), IsCheckedOut(ischeckedout), DueDate(duedate) {
}

std::string LibraryItem::getTitle() const {
    return Title;
}

bool LibraryItem::getIsCheckedOut() const {
    return IsCheckedOut;
}

std::string LibraryItem::getDueDate() const {
    return DueDate;
}

void LibraryItem::setTitle(const std::string& newTitle) {
    Title = newTitle;
}

void LibraryItem::setIsCheckedOut(bool newIsCheckedOut) {
    IsCheckedOut = newIsCheckedOut;
}

void LibraryItem::setDueDate(const std::string& newDueDate) {
    DueDate = newDueDate;
}

void LibraryItem::checkOut(const std::string& dueDate) {
    DueDate = dueDate;
    IsCheckedOut = true;
}

void LibraryItem::returnItem() {
    IsCheckedOut = false;
    DueDate = "Returned";
}
