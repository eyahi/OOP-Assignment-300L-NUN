#include "BookItem.h"
#include "Patron.h"
#include "Library.h"

int main(){
    BookItem book1("Object Oriented Programming", true, "15/01/2024", "Barde Nathaniel", "211203066");
    BookItem book2("Life Changer", false, "Not borrowed", "Obi Samuel", "678-3-06-225117-5");

    std::cout << "Title: " << book1.getTitle() << '\n' << "Author: " << book1.getAuthor() << '\n' << "ISBN: " << book1.getISBN() << '\n' << std::endl; 
    std::cout << "Title: " << book2.getTitle() << '\n' << "Author: " << book2.getAuthor() << '\n' << "ISBN: " << book2.getISBN() << '\n' << std::endl; 

    std::cout << std::endl;
    Patron patron1("Mr. Ali Emmanuel", "15/01/2024");
    patron1.displayInfo();

    Library library;
    library.addBook(book1);
    library.addBook(book2);

    library.addPatron(patron1);
    library.borrowBook(patron1, book1, "15/01/2024");
    std::cout << '\n';

    std::cout << "The Patron Borrowed a book\n";
    library.borrowBook(patron1, book1, "15-01-2024");

    const PatronRecord& patron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& patron1CheckedOutBooks = patron1Record.getCheckedOutBooks();

    if (!patron1CheckedOutBooks.empty()) {
        const BookItem& borrowedBook = patron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " borrowed a book:\n";
        std::cout << "Title: " << borrowedBook.getTitle() << '\n';
        std::cout << "Author: " << borrowedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << borrowedBook.getISBN() << '\n';
        std::cout << "Due Date: " << borrowedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " did not borrowed any books.\n";
    }

    std::cout << '\n';

std::cout << '\n' << "Books remaining: \n";
for (const auto& book : library.getBooks()) {
    std::cout << "Title: " << book.getTitle() << '\n';
    std::cout << "Author: " << book.getAuthor() << '\n';
    std::cout << "ISBN: " << book.getISBN() << '\n';
    std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
    std::cout << "Due Date: " << book.getDueDate() << '\n';
    std::cout << '\n';
}

    std::cout << "Patron Returned a books...\n";
    library.returnBook(patron1, book1);

    const PatronRecord& updatedPatron1Record = library.getPatronRecord(patron1);
    const std::vector<BookItem>& updatedPatron1CheckedOutBooks = updatedPatron1Record.getCheckedOutBooks();

    if (!updatedPatron1CheckedOutBooks.empty()) {
        const BookItem& returnedBook = updatedPatron1CheckedOutBooks.back();
        std::cout << "Patron " << patron1.getName() << " returned the following book:\n";
        std::cout << "Title: " << returnedBook.getTitle() << '\n';
        std::cout << "Author: " << returnedBook.getAuthor() << '\n';
        std::cout << "ISBN: " << returnedBook.getISBN() << '\n';
        std::cout << "Due Date: " << returnedBook.getDueDate() << '\n';
    } else {
        std::cout << "Patron " << patron1.getName() << " did not borrowed any books.\n";
    }

    std::cout << '\n' << "Remaining Books after returning:\n";
    for (const auto& book : library.getBooks()) {
        std::cout << "Title: " << book.getTitle() << '\n';
        std::cout << "Author: " << book.getAuthor() << '\n';
        std::cout << "ISBN: " << book.getISBN() << '\n';
        std::cout << "Is Checked Out: " << (book.getIsCheckedOut() ? "Yes" : "No") << '\n';
        std::cout << "Due Date: " << book.getDueDate() << '\n';
        std::cout << '\n';
    }

    return 0;
}

