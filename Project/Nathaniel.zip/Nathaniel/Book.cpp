#include "Book.h"
#include <iostream>

Book::Book(std::string title, std::string author, int isbn)
    : Title(title), Author(author), ISBN(isbn) {
}
std::string Book::getTitle() const {
    return Title;
}
std::string Book::getAuthor() const {
    return Author;
}
int Book::getISBN() const {
    return ISBN;
}
void Book::setTitle(const std::string& newTitle) {
    Title = newTitle;
}
void Book::setAuthor(const std::string& newAuthor) {
    Author = newAuthor;
}
void Book::setISBN(int newISBN) {
    ISBN = newISBN;
}

