#include <iostream>
#include <vector>
#include <ctime>
#include <algorithm>

class LibraryItem {
private:
    std::string title;
    bool isCheckedOut;
    time_t dueDate;

public:
    LibraryItem(const std::string& _title) : title(_title), isCheckedOut(false), dueDate(0) {}

    const std::string& getTitle() const {
        return title;
    }

    bool getIsCheckedOut() const {
        return isCheckedOut;
    }

    time_t getDueDate() const {
        return dueDate;
    }

    void checkOut() {
        if (!isCheckedOut) {
            isCheckedOut = true;
            // Set due date to one week from today
            dueDate = time(nullptr) + 7 * 24 * 60 * 60;
            std::cout << "Item checked out successfully.\n";
        } else {
            std::cout << "Item is already checked out.\n";
        }
    };

    virtual void returnItem() {
        if (isCheckedOut) {
            isCheckedOut = false;
            dueDate = 0;
            std::cout << "Item returned successfully.\n";
        } else {
            std::cout << "Item is not checked out.\n";
        }
    }
};

class BookItem : public LibraryItem {
private:
    std::string author;
    std::string isbn;

public:
    BookItem(const std::string& _title, const std::string& _author, const std::string& _isbn)
        : LibraryItem(_title), author(_author), isbn(_isbn) {}

    const std::string& getAuthor() const {
        return author;
    }

    const std::string& getISBN() const {
        return isbn;
    }

    void displayBookInfo() const {
        std::cout << "Title: " << getTitle() << "\n";
        std::cout << "Author: " << author << "\n";
        std::cout << "ISBN: " << isbn << "\n";
        std::cout << "Checked Out: " << (getIsCheckedOut() ? "Yes" : "No") << "\n";
        if (getIsCheckedOut()) {
            std::cout << "Due Date: " << time_t(getDueDate());
        }
    }

    // Override returnItem to add ] functionality 
    void returnItem() override {
        LibraryItem::returnItem();
    }
};

class PatronRecord {
private:
    std::vector<BookItem*> checkedOutBooks;

public:
    void addBook(BookItem* book) {
        checkedOutBooks.push_back(book);
    }

    void removeBook(BookItem* book) {
        auto it = find(checkedOutBooks.begin(), checkedOutBooks.end(), book);
        if (it != checkedOutBooks.end()) {
            checkedOutBooks.erase(it);
        }
    }

    const std::vector<BookItem*>& getCheckedOutBooks() const {
        return checkedOutBooks;
    }
};

class Patron {
private:
    std::string name;
    int libraryCardNumber;
    PatronRecord patronRecord;

public:
    Patron(const std::string& _name, int _libraryCardNumber)
        : name(_name), libraryCardNumber(_libraryCardNumber) {}

    const std::string& getName() const {
        return name;
    }

    int getLibraryCardNumber() const {
        return libraryCardNumber;
    }

    PatronRecord& getPatronRecord() {
        return patronRecord;
    }
};

class Library {
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;

public:
    void addBook(const std::string& title, const std::string& author, const std::string& isbn) {
        books.emplace_back(title, author, isbn);
    }

    void addPatron(const std::string& name, std::string libraryCardNumber) {
        patrons.emplace_back(name, libraryCardNumber);
    }

    void borrowBook(Patron& patron, BookItem& book) {
        if (!book.getIsCheckedOut()) {
            book.checkOut();
            patron.getPatronRecord().addBook(&book);
            std::cout << "Book borrowed successfully.\n";
        } else {
            std::cout << "Book is already checked out.\n";
        }
    }

    void returnBook(Patron& patron, BookItem& book) {
        book.returnItem();
        patron.getPatronRecord().removeBook(&book);
        std::cout << "Book returned successfully.\n";
    }

    const std::vector<BookItem>& getBooks() const {
        return books;
    }

    const std::vector<Patron>& getPatrons() const {
        return patrons;
    }
};

int main() {
    Library library;

    // Adding books to the library
    library.addBook("Introduction to OOP","Agboola Dolapo","211203004");
    library.addBook("Harry Potter and the Sorcerer's Stone", "Dolapo" ,"GET 303 9900997");

    // Adding patrons to the library
    library.addPatron("Dr Emmanuel", "15-01-2024"); 
    library.addPatron("Barka Peter", "55696056");

    // Borrowing and returning books
    Patron& alice = const_cast<Patron&>(library.getPatrons()[0]);  
    BookItem& lotr = const_cast<BookItem&>(library.getBooks()[0]);  

    library.borrowBook(alice, lotr);
    library.returnBook(alice, lotr);

    return 0;
}
