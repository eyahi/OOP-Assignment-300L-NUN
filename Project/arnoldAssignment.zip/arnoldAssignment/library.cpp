#include <iostream>
#include <string>
#include <vector>

#include "library.h"


//make sure that every book has a unique isbn
void Library::addBook(std::string author, std::string isbn, std::string title) {
    books.push_back(BookItem(author, isbn, title, false));
    std::cout << "Book Successfully Added.\n" << std::endl;
}

//make sure every patron has a unique library card number
void Library::addPatron(std::string name, std::string libraryCardNumber) {
    patrons.push_back(Patron(name, libraryCardNumber));
    std::cout << "Patron Successfully Added.\n" << std::endl;
}

void Library::checkOut(std::string name, std::string libraryCardNumber, std::string author, std::string isbn, std::string title){
    for (int i = 0; i < books.size(); i++){
        if (books[i].getTitle() == title){
            if (books[i].getIsCheckedOut() == false){

                patronRecords.push_back(PatronRecord(name, libraryCardNumber, author, isbn, title, true));
                books[i].setIscheckedOut(true);
                std::cout << "Book Successfully Checked Out. Enjoy your Book.\n" << std::endl;
                break;
            }
            else {
                std::cout << "Book Has Already been Checked Out. Try Out Another Book.\n" << std::endl;
                break;
            }   
        }
        else {
            if (i == (books.size() - 1)) {
                std::cout << "Book Not In Selection. " << std::endl;
                break;
            }
        }
    }   
}

void Library::returnItem(std::string title, std::string libraryNumber){
    for (int i = 0; i < books.size(); i++){
        if(books[i].getTitle() == title) {
            books[i].setIscheckedOut(false);
        }
    }
    
    for (int i = 0; i < patronRecords.size(); i++){
        if (patronRecords[i].getTitle() == title && patronRecords[i].getLibraryCardNumber() == libraryNumber) {
            patronRecords[i].setIscheckedOut(false);
            std::cout << "Book Successfully Returned. Please Come Again.\n" << std::endl;
            break;
        }
        else {
            std::cout << "Invalid Book or Library Card Number. Please Check your inputs.\n" << std::endl;
            break;
        }
    }
}