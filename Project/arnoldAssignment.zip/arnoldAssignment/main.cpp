#include <iostream>

#include "library.h"

int main() {

    Library library1;
    
    std::cout << "Adding a Book..................." << std::endl;
    library1.addBook("Okafor Nzube", "211203028", "CPE303 - Object Oriented Programming");

    std::cout << "Adding a Patron................." << std::endl;
    library1.addPatron("Dr. Emmanuel Ali", "2024-1-24");

    std::cout << "Borrowing a Book................" << std::endl;
    library1.checkOut("Dr. Emmanuel Ali", "2024-1-24", "Okafor Nzube", "211203028", "CPE303 - Object Oriented Programming");

    std::cout << "Returning a Book................" << std::endl;
    library1.returnItem("CPE303 - Object Oriented Programming", "2024-1-24");

    return 0;

}