#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <string>

class LibraryItem {
private:
    // LibraryItem attributes
    std::string Title;
    bool IsCheckedOut = false;

public:
    // getter functions
    std::string getTitle() { return Title; }
    bool getIsCheckedOut() { return IsCheckedOut; }

    //setter functions
    void setTitle(std::string title) { Title = title; }
    void setIscheckedOut(bool isCheckedOut) { IsCheckedOut = isCheckedOut; }

    // LibraryItem constructor
    LibraryItem(std::string title, bool isCheckedOut) : Title(title), IsCheckedOut(isCheckedOut) {}
};

#endif