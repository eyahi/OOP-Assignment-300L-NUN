#ifndef BOOKITEM_H
#define BOOKITEM_H

#include <string>

#include "libraryItem.h"

class BookItem : public LibraryItem {
private:
    std::string Author;
    std::string Isbn;

public:
    //getter functions
    std::string getAuthor() { return Author; }
    std::string getIsbn() { return Isbn; }

    //setter functions
    void setAuthor(std::string author) { Author = author; }
    void setIsbn(std::string isbn) { Isbn = isbn; }

    //BookItem constructor
    BookItem(std::string author, std::string isbn, std::string title, bool isCheckedOut) : Author(author), Isbn(isbn), LibraryItem(title, isCheckedOut) {}
};

#endif