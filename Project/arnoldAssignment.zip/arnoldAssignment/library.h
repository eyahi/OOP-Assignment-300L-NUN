#ifndef LIBRARY_H
#define LIBRARY_H

#include <string>
#include <vector>

#include "bookItem.h"
#include "patron.h"
#include "patronRecord.h"

class Library {
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:

    void addBook(std::string author, std::string isbn, std::string title);

    void addPatron(std::string name, std::string libraryCardNumber);

    void checkOut(std::string name, std::string libraryCardNumber, std::string author, std::string isbn, std::string title);

    void returnItem(std::string title, std::string libraryNumber);

};

#endif