#ifndef PATRONRECORD_H
#define PATRONRECORD_H

#include <string>

#include "bookItem.h"
#include "patron.h"

class PatronRecord : public Patron, public BookItem {
public:

    //PatronRecord constructor
    PatronRecord(std::string name, std::string libraryCardNumber, std::string author, std::string isbn, std::string title, bool isCheckedOut) : Patron(name, libraryCardNumber), BookItem(author, isbn, title, isCheckedOut) {}
};

#endif