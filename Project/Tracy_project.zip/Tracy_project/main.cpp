// main.cpp
#include <iostream>
#include "book.h"
#include "patron.h"
#include "book_item.h"
#include "patron_record.h"
#include "library.h"

int main() {

    // Set details for Tracy Amos-Nkpa's book
    BookItem tracyBook("CPE303", "Tracy Amos-Nkpa", "211204020");

    // Create instances of patrons
    Patron patron1("Dr_Ali", "12345");

    // Create a library
    Library library;

    // Add books to the library
    library.addBook(book1);
    library.addBook(book2);

    // Add patrons to the library
    library.addPatron(patron1);
    library.addPatron(patron2);

    // Perform borrowing and returning operations
    library.borrowBook(patron1, book1);
    library.borrowBook(patron2, book2);

    library.returnBook(patron1, book1);

    // Display checked-out books for patrons
    /* 
const std::vector<BookItem>& patron1CheckedOutBooks = library.getPatronRecords()[0].getCheckedOutBooks();
    const std::vector<BookItem>& patron2CheckedOutBooks = library.getPatronRecords()[1].getCheckedOutBooks();

    std::cout << "Books checked out by " << patron1.getName() << ":\n";
    for (const auto& book : patron1CheckedOutBooks) {
        std::cout << book.getTitle() << "\n";
    }

    std::cout << "Books checked out by " << patron2.getName() << ":\n";
    for (const auto& book : patron2CheckedOutBooks) {
        std::cout << book.getTitle() << "\n";
    } 
*/

    return 0;
}
