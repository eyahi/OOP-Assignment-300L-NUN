// library_item.h
#ifndef LIBRARY_ITEM_H
#define LIBRARY_ITEM_H

#include <string>

class LibraryItem {
private:
    std::string title;
    bool isCheckedOut;
    std::string dueDate;

public:
    LibraryItem(const std::string& title);

    // Getter and Setter methods
    std::string getTitle() const;
    void setTitle(const std::string& title);

    bool getIsCheckedOut() const;
    void setIsCheckedOut(bool isCheckedOut);

    std::string getDueDate() const;
    void setDueDate(const std::string& dueDate);

    // Member functions
    void checkOut(const std::string& dueDate);
    void returnItem();
};

#endif // LIBRARY_ITEM_H
