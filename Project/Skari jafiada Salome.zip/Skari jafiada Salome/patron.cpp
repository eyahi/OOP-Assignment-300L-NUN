/ patron.h
#ifndef PATRON_H
#define PATRON_H

#include <string>

class Dremmanuel {
private:
    std::string name;
    std::string libraryCardNumber;

public:
    Dremmanuel(const std::string& name, const std::string& libraryCardNumber);

    // Getter and Setter methods
    std::string getName() const;
    void setName(const std::string& name);

    std::string getLibraryCardNumber() const;
    void setLibraryCardNumber(const std::string& libraryCardNumber);
};

#endif // PATRON_H