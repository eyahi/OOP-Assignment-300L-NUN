#include "library.h"
#include <iostream>

int main()
{
    // Create instances of books
    BookItem book1("CPE303", "FATIMA_UMAR", "211203026");

    // Create  instances of patrons
    Patron patron1("DR_ALI", "15TH_JAN_2024");

    // Create an instance of the library
    Library library;

    // Add books to the library
    library.addBook(book1);

    // Add patrons to the library
    library.addPatron(patron1);

    // Borrow books
    library.borrowBook(patron1, book1);

    // Try to borrow a book that is already checked out
    library.borrowBook(patron1, book1);

    // Return books
    library.returnBook(patron1, book1);

    return 0;
}
