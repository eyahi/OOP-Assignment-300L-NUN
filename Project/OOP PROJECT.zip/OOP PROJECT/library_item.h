#ifndef LIBRARY_ITEM_H
#define LIBRARY_ITEM_H

#include <string>

class LibraryItem
{
private:
    std::string title;
    bool checkedOut;
    std::string dueDate;

public:
    // Constructor
    LibraryItem(const std::string& title, bool checkedOut = false, const std::string& dueDate = "")
        : title(title), checkedOut(checkedOut), dueDate(dueDate)
    {
    }

    // Setters
    void setTitle(const std::string& newTitle) { title = newTitle; }

    void checkOut(const std::string& newDueDate)
    {
        checkedOut = true;
        dueDate = newDueDate;
    }

    void returnItem()
    {
        checkedOut = false;
        dueDate.clear();
    }

    // Getters
    std::string getTitle() const { return title; }

    bool isCheckedOut() const { return checkedOut; }

    std::string getDueDate() const { return dueDate; }
};

#endif // LIBRARY_ITEM_H
