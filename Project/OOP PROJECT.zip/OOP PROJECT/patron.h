#ifndef PATRON_H
#define PATRON_H

#include <string>

class Patron
{
private:
    std::string name;
    std::string libraryCardNumber;

public:
    // Constructors
    Patron() : name(""), libraryCardNumber("") {}
    Patron(const std::string& name, const std::string& libraryCardNumber)
        : name(name), libraryCardNumber(libraryCardNumber) {}

    // Setters
    void setName(const std::string& newName) { name = newName; }

    void setLibraryCardNumber(const std::string& newLibraryCardNumber) { libraryCardNumber = newLibraryCardNumber; }

    // Getters
    std::string getName() const { return name; }

    std::string getLibraryCardNumber() const { return libraryCardNumber; }
};

#endif // PATRON_H
