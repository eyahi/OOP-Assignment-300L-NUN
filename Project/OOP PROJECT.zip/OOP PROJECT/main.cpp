#include "library.h"
#include <iostream>

int main()
{
    BookItem book1("Introduction to OOP", "Baba Al-amin Salihu", "211203007");

    Patron patron1("Dr Emmanuel Ali", "15th January 2024");

    Library library;

    library.addBook(book1);

    library.addPatron(patron1);

    library.borrowBook(patron1, book1, "15th January 2024");

    library.borrowBook(patron1, book1, "20th January 2024");

    library.returnBook(patron1, book1);

    return 0;
}
