#ifndef LIBRARY_H
#define LIBRARY_H

#include <iostream>
#include <vector>
#include <algorithm>
#include "book_item.h"
#include "patron.h"
#include "patron_record.h"

class Library
{
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:
    // Functions for managing books and patrons, borrowing and returning books
    void addBook(const BookItem& book) { books.push_back(book); }

    void addPatron(const Patron& patron)
    {
        patrons.push_back(patron);
        patronRecords.emplace_back(patron);
    }

    void borrowBook(const Patron& patron, BookItem& book, const std::string& dueDate)
    {
        if (!book.isCheckedOut())
        {
            book.checkOut(dueDate);

            bool foundPatronRecord = false;

            for (auto& record : patronRecords)
            {
                if (record.getPatron().getLibraryCardNumber() == patron.getLibraryCardNumber())
                {
                    foundPatronRecord = true;
                    record.addCheckedOutBook(book);
                    std::cout << "Hey, " << patron.getName() << "! You've borrowed '" << book.getTitle() << "'. Enjoy reading!\n";
                    break;  // Exit the loop once the patron record is found
                }
            }

            if (!foundPatronRecord)
            {
                std::cerr << "Oops! Couldn't find your record, " << patron.getName() << ". Please check with the librarian.\n";
            }
        }
        else
        {
            std::cout << "Sorry, " << patron.getName() << ". '" << book.getTitle() << "' is already checked out.\n";
        }
    }

    void returnBook(const Patron& patron, BookItem& book)
    {
        bool foundPatronRecord = false;

        for (auto& record : patronRecords)
        {
            if (record.getPatron().getLibraryCardNumber() == patron.getLibraryCardNumber())
            {
                foundPatronRecord = true;

                if (record.hasCheckedOutBook(book))
                {
                    book.returnItem();
                    record.removeCheckedOutBook(book);
                    std::cout << "Welcome back, " << patron.getName() << "! You've returned '" << book.getTitle() << "'. Thanks!\n";
                }
                else
                {
                    std::cerr << "Oops! Looks like you haven't borrowed '" << book.getTitle() << "', " << patron.getName() << ".\n";
                }

                break;  // Exit the loop once the patron record is found
            }
        }

        if (!foundPatronRecord)
        {
            std::cerr << "Oops! Couldn't find your record, " << patron.getName() << ". Please check with the librarian.\n";
        }

    }
};

#endif // LIBRARY_H
