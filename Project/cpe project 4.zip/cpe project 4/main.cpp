#include "library.h"
#include <iostream>

int main()
{
    BookItem book1("Introduction to OOP", "Bashir Mohammed Aliyu", "211203016");

    Patron patron1("Dr Ali", "15/01/2024");

    Library library;

    library.addBook(book1);

    library.addPatron(patron1);

    library.borrowBook(patron1, book1);

    library.borrowBook(patron1, book1);

    library.returnBook(patron1, book1);

    return 0;
}
