#ifndef PATRON_RECORD_H
#define PATRON_RECORD_H
#include <vector>
#include "book_item.h"
#include "patron.h"
class PatronRecord
{
private:
    Patron patron;
    std::vector<BookItem> checkedOutBooks;

public:
    PatronRecord(const Patron &patron)
    {
        this->patron = patron;
    }
    // Functions for managing checked out books
    void addCheckedOutBook(const BookItem &book)
    {
        checkedOutBooks.push_back(book);
    }

    void removeCheckedOutBook(const BookItem &book)
    {
        checkedOutBooks.erase(
            std::remove_if(checkedOutBooks.begin(), checkedOutBooks.end(),
                           [&book](const BookItem &checkedBook)
                           {
                               return checkedBook.getIsbn() == book.getIsbn();
                           }),
            checkedOutBooks.end());
    }

    bool hasCheckedOutBook(BookItem book)
    {
        auto it = std::find_if(checkedOutBooks.begin(), checkedOutBooks.end(),
                               [&book](const BookItem &checkedBook)
                               {
                                   return checkedBook.getIsbn() == book.getIsbn();
                               });

        if (it != checkedOutBooks.end())
        {
            return true;
        }

        return false;
    }

    Patron
    getPatron() const
    {
        return this->patron;
    }
};
#endif // PATRON_RECORD_H