//Library Class

#ifndef LIBRARY_H
#define LIBRARY_H

#include <vector>
#include "book_item.h"
#include "patron.h"
#include "patron_record.h"

class Library {
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:
    // Functions for managing books and patrons, borrowing and returning books
    void addBook(const std::string& title, const std::string& author, const std::string& isbn) {
        // Set values based on your requirements
        BookItem newBook(title, author, isbn);
        // ... other initialization as needed ...

        // Add the book to the library
        books.push_back(newBook);
    }
    void addPatron(const std::string& name, const std::string& libraryCardNumber) {
        // Set values based on your requirements
        Patron newPatron(name, libraryCardNumber);
        // ... other initialization as needed ...

        // Add the patron to the library
        patrons.push_back(newPatron);
        // Initialize a record for the patron
        patronRecords.push_back(PatronRecord());
    }
    void borrowBook(const Patron& patron, const BookItem& book);
    void returnBook(const Patron& patron, const BookItem& book);
};

#endif // LIBRARY_H