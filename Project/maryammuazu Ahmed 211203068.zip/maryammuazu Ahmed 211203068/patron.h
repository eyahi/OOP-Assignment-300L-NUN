// patron.h
#ifndef PATRON_H
#define PATRON_H

#include <string>

class Patron {
private:
    std::string name;
    std::string libraryCardNumber;

public:
    // Constructor
    Patron(std::string name, std::string libraryCardNumber);

    // Getters and setters
    std::string getName() const;
    void setName(const std::string& name);
    std::string getLibraryCardNumber() const;
    void setLibraryCardNumber(const std::string& cardNumber);
};

#endif // PATRON_H
