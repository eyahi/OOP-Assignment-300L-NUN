// library_item.cpp
#include "library_item.h"

// Constructor
LibraryItem::LibraryItem(std::string title)
    : title(title), isCheckedOut(false), dueDate("") {}

// Getters and setters
std::string LibraryItem::getTitle() const {
    return title;
}

void LibraryItem::setTitle(const std::string& title) {
    this->title = title;
}

bool LibraryItem::getIsCheckedOut() const {
    return isCheckedOut;
}

void LibraryItem::setIsCheckedOut(bool isCheckedOut) {
    this->isCheckedOut = isCheckedOut;
}

std::string LibraryItem::getDueDate() const {
    return dueDate;
}

void LibraryItem::setDueDate(const std::string& dueDate) {
    this->dueDate = dueDate;
}

// Member functions
void LibraryItem::checkOut() {
    if (!isCheckedOut) {
        isCheckedOut = true;
        // Set due date logic can be added here
    }
}

void LibraryItem::returnItem() {
    if (isCheckedOut) {
        isCheckedOut = false;
        dueDate = "";
    }
}
