// main.cpp
#include "library.h"
#include <iostream>

int main() {
    // Create library instance
    Library library;

    // Create a book
    BookItem book("Introduction to C++", "John Doe", "123456789");

    // Add book to the library
    library.addBook(book);

    // Create a patron
    Patron patron("Maryam Muazu Ahmed", "20240115");

    // Add patron to the library
    library.addPatron(patron);

    // Borrow a book
    library.borrowBook(patron, book);

    // Return a book
    library.returnBook(patron, book);

    return 0;
}
