// book.h
#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    std::string title;
    std::string author;
    std::string isbn;

public:
    // Constructor
    Book(std::string title, std::string author, std::string isbn);

    // Getters and setters
    std::string getTitle() const;
    void setTitle(const std::string& title);
    std::string getAuthor() const;
    void setAuthor(const std::string& author);
    std::string getISBN() const;
    void setISBN(const std::string& isbn);
};

#endif // BOOK_H
