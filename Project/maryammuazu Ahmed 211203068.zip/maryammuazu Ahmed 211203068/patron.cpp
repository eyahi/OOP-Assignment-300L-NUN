// patron.cpp
#include "patron.h"

// Constructor
Patron::Patron(std::string name, std::string libraryCardNumber)
    : name(name), libraryCardNumber(libraryCardNumber) {}

// Getters and setters
std::string Patron::getName() const {
    return name;
}

void Patron::setName(const std::string& name) {
    this->name = name;
}

std::string Patron::getLibraryCardNumber() const {
    return libraryCardNumber;
}

void Patron::setLibraryCardNumber(const std::string& cardNumber) {
    libraryCardNumber = cardNumber;
}
