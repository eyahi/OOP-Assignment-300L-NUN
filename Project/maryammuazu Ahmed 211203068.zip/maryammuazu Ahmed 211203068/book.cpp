// book.cpp
#include "book.h"

// Constructor
Book::Book(std::string title, std::string author, std::string isbn)
    : title(title), author(author), isbn(isbn) {}

// Getters and setters
std::string Book::getTitle() const {
    return title;
}

void Book::setTitle(const std::string& title) {
    this->title = title;
}

std::string Book::getAuthor() const {
    return author;
}

void Book::setAuthor(const std::string& author) {
    this->author = author;
}

std::string Book::getISBN() const {
    return isbn;
}

void Book::setISBN(const std::string& isbn) {
    this->isbn = isbn;
}
