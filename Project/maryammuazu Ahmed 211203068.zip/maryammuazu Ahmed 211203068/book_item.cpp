// book_item.cpp
#include "book_item.h"

// Constructor
BookItem::BookItem(std::string title, std::string author, std::string isbn)
    : LibraryItem(title), author(author), isbn(isbn) {}

// Getters and setters
std::string BookItem::getAuthor() const {
    return author;
}

void BookItem::setAuthor(const std::string& author) {
    this->author = author;
}

std::string BookItem::getISBN() const {
    return isbn;
}

void BookItem::setISBN(const std::string& isbn) {
    this->isbn = isbn;
}
