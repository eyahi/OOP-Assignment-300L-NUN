// library_item.h
#ifndef LIBRARY_ITEM_H
#define LIBRARY_ITEM_H

#include <string>

class LibraryItem {
private:
    std::string title;
    bool isCheckedOut;
    std::string dueDate;

public:
    // Constructor
    LibraryItem(std::string title);

    // Getters and setters
    std::string getTitle() const;
    void setTitle(const std::string& title);
    bool getIsCheckedOut() const;
    void setIsCheckedOut(bool isCheckedOut);
    std::string getDueDate() const;
    void setDueDate(const std::string& dueDate);

    // Member functions
    void checkOut();
    void returnItem();
};

#endif // LIBRARY_ITEM_H
