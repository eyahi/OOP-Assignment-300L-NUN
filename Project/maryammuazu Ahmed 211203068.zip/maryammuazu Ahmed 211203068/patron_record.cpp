// patron_record.cpp
#include "patron_record.h"

// Functions for managing checked out books
void PatronRecord::addBook(const BookItem& book) {
    checkedOutBooks.push_back(book);
}

void PatronRecord::removeBook(const BookItem& book) {
    // Logic to remove the book from the checkedOutBooks vector
}
