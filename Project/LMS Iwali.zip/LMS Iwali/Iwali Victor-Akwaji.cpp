#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <unordered_map>

class Book {
private:
    std::string title;
    std::string author;
    std::string isbn;

public:
    Book(const std::string& title, const std::string& author, const std::string& ISBN) : title(title), author(author), isbn(isbn) {}

    std::string getTitle() const {
        return title;
    }

    std::string getAuthor() const {
        return author;
    }
    
     std::string getIsbn() const {
        return isbn;
    }

};


// Base class representing an item in the library
class LibraryItem {
public:
    LibraryItem(const std::string& title, bool isCheckedOut = false)
        : title(title), isCheckedOut(isCheckedOut) {}

    const std::string& getTitle() const {
        return title;
    }

    bool getIsCheckedOut() const {
        return isCheckedOut;
    }

    void checkOut() {
        isCheckedOut = true;
        dueDate = time(nullptr) + 2 * 24 * 60 * 60; // Due date 2 days from now
    }

    void returnItem() {
        isCheckedOut = false;
        dueDate = 0;
    }

    virtual void displayInfo() const = 0;

protected:
    std::string title;
    bool isCheckedOut;
    time_t dueDate;
};

// Derived class representing a book in the library
class BookItem : public LibraryItem {
public:
    BookItem(const std::string& title, const std::string& author, const std::string& isbn)
        : LibraryItem(title), author(author), isbn(isbn) {}

    void displayInfo() const override {
        std::cout << "Title: " << title << "\nAuthor: " << author << "\nISBN: " << isbn << "\n";
    }

private:
    std::string author;
    std::string isbn;
};

// Class representing a patron in the library
class Patron {
public:
    Patron(const std::string& name, int libraryCardNumber)
        : name(name), libraryCardNumber(libraryCardNumber) {}

    const std::string& getName() const {
        return name;
    }

    int getLibraryCardNumber() const {
        return libraryCardNumber;
    }

private:
    std::string name;
    int libraryCardNumber;
};

// Class representing a patron's record of checked-out books
class PatronRecord {
public:
    void addBook(const std::string& bookTitle) {
        checkedOutBooks.push_back(bookTitle);
    }

    void removeBook(const std::string& bookTitle) {
        for (auto it = checkedOutBooks.begin(); it != checkedOutBooks.end(); ++it) {
            if (*it == bookTitle) {
                checkedOutBooks.erase(it);
                break;
            }
        }
    }

    void displayCheckedOutBooks() const {
        std::cout << "Checked-out Books:\n";
        for (const auto& book : checkedOutBooks) {
            std::cout << "- " << book << "\n";
        }
    }

private:
    std::vector<std::string> checkedOutBooks;
};

// Library class managing books and patrons
class Library {
public:
    void addBookItem(BookItem* book) {
        bookItems.push_back(book);
    }

    void addPatron(Patron* patron) {
        patrons.push_back(patron);
    }

    void displayAllBooks() const {
        std::cout << "Library Books:\n";
        for (const auto& book : bookItems) {
            book->displayInfo();
            std::cout << "\n";
        }
    }

    void displayAllPatrons() const {
        std::cout << "Patrons:\n";
        for (const auto& patron : patrons) {
            std::cout << "Name: " << patron->getName() << ", Library Card Number: " << patron->getLibraryCardNumber() << "\n";
        }
    }

    void borrowBook(Patron* patron, BookItem* book) {
        if (!book->getIsCheckedOut()) {
            book->checkOut();
            patronRecords[patron->getLibraryCardNumber()].addBook(book->getTitle());
            std::cout << patron->getName() << " has borrowed: " << book->getTitle() << "\n";
        } else {
            std::cout << "Sorry, the book is already checked out.\n";
        }
    }

    void returnBook(Patron* patron, BookItem* book) {
        if (book->getIsCheckedOut()) {
            book->returnItem();
            patronRecords[patron->getLibraryCardNumber()].removeBook(book->getTitle());
            std::cout << patron->getName() << " has returned: " << book->getTitle() << "\n";
        } else {
            std::cout << "This book is not checked out.\n";
        }
    }

    void displayPatronCheckedOutBooks(Patron* patron) const {
        std::cout << patron->getName() << "'s Checked-out Books:\n";
        patronRecords.at(patron->getLibraryCardNumber()).displayCheckedOutBooks();
    }

private:
    std::vector<BookItem*> bookItems;
    std::vector<Patron*> patrons;
    std::unordered_map<int, PatronRecord> patronRecords; // Maps library card number to PatronRecord
};

int main() {
    // Create library
    Library library;

    // Add books to the library
    BookItem* book1 = new BookItem("Introduction To Object Oriented Programming CPE 303", "Iwali Victor-Akwaji", "211203022");
    BookItem* book2 = new BookItem("New School Chemistry", "A.P. John", "9451100125564");
    library.addBookItem(book1);
    library.addBookItem(book2);

    // Add patrons to the library
    Patron* patron1 = new Patron("Dr. Emmanuel Ali", 15012024);
    Patron* patron2 = new Patron("Mr.Johnson", 16012024);
    library.addPatron(patron1);
    library.addPatron(patron2);

    // Display all books and patrons in the library
    library.displayAllBooks();
    library.displayAllPatrons();

    // Perform borrowing and returning
    library.borrowBook(patron1, book1);
    library.borrowBook(patron2, book2);

    library.borrowBook(patron1, book2); // Trying to borrow an already borrowed book

    // Display checked-out books for patrons
    library.displayPatronCheckedOutBooks(patron1);
    library.displayPatronCheckedOutBooks(patron2);

    library.returnBook(patron1, book1);
    library.returnBook(patron2, book2);

    // Clean up dynamic memory
    delete book1;
    delete book2;
    delete patron1;
    delete patron2;

    return 0;
}
