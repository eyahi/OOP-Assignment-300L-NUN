#include<iostream>
#ifndef PATRON_H
#define PATRON_H
using namespace std;
class Patron{
    string name;
    string libraryCardNumber;
public:
Patron(string Name, string LibraryCardNumber);
string getName();
string getLibraryCardNumber();
void setInfo(string Name,string LibraryCardNumber);

   
};
#endif
