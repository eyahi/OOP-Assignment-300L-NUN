#ifndef LIBRARY_H
#define LIBRARY_H
#include<vector>
#include "book_item.h"
#include "patron_record.h"

class Library{
private:
    vector<BookItem> bookCollection;
    vector<PatronRecord> patronCollection;
public:
    void addBook(BookItem book){
        bookCollection.push_back(book);
    }
    void addPatron(PatronRecord patron){
        patronCollection.push_back(patron);
    }
    void borrowBook(BookItem book, PatronRecord patron) {
        book.setAvailability(); //modify here
        patron.addBook(&book);
    }

    void returnBook(BookItem book, PatronRecord patron) {
        book.setAvailability(); //and here
        patron.removeBook(&book);
    }
};
#endif