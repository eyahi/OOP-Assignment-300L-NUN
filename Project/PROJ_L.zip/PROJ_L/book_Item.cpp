#include<iostream>
#include "library_item.h"
using namespace std;
class BookItem:public LibraryItem{
    public:
    string author;
    string isbn;
    string title;
    BookItem(string Title,bool IsCheckedOut,string DueDate, string Author, string Isbn) : LibraryItem(Title, IsCheckedOut, DueDate), author(Author), isbn(Isbn) {};
    string getAuthor(){
        return author;
    }
    string getIsbn(){
        return isbn;
    }
    string getTitle(){
        return title;
    }
    void setAuthor(string author) { this->author = author; }
    void setIsbn(string isbn) { this->isbn = isbn; }
   
};