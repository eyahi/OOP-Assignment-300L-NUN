#ifndef PATRON_RECORD_H
#define PATRON_RECORD_H
#include <vector>
#include "book_item.h"
class BookItem;
class PatronRecord{
    private:
    string name;
    string lcn;
    vector<BookItem*>checkedOutBooks;
    public:
    PatronRecord(string name, string lcn);
    string getName() const;
    void setName(string name);
    void addBook(BookItem* book);
    void removeBook(BookItem* book);
    void displayCheckedOutBooks() const;

};
#endif
