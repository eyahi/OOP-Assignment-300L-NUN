#include<iostream>
using namespace std;
#include "patron_record.h"
#include "book_item.h"
#include "iostream"
#include<algorithm>
void PatronRecord::addBook(BookItem* book){
    checkedOutBooks.push_back(book);
}
void PatronRecord::removeBook(BookItem*book){
    auto found= find(checkedOutBooks.begin(),checkedOutBooks.end(),book);
    if (found!= checkedOutBooks.end()){
        checkedOutBooks.erase(found);
    }
}
void PatronRecord::displayCheckedOutBooks() const {
    cout<<"Checked Out Books:\n";
    for (const auto& book : checkedOutBooks) {
        std::cout << "- " << book->getTitle() << "\n";
    }
}