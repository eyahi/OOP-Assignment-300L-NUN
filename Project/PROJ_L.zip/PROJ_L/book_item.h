#ifndef BOOK_ITEM_H
#define BOOK_ITEM_H
#include "library_item.h"
class BookItem: public LibraryItem{
private:
    string author;
    string isbn;
    string title;
public:
    BookItem(string title,string author,string isbn);
    string getAuthor() const;
    string getIsbn() const;
    string getTitle() const;
    void setAuthor (string author);
    void setIsbn(string isbn);
    void setAvailability() {}; //make setAvailability function here
};
#endif