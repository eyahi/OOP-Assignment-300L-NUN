#include <iostream>

using namespace std;

class Book {
    public:
        string title;
        string author;
        string ISBN;

        Book (string Title, string Author,  string _ISBN) : title(Title), author(Author), ISBN(_ISBN) {};

        void getInfo(){
            cout << "Book Title: " << title << endl << "Author: " << author << endl << "ISBN: " << ISBN << endl; 
        }

        void setInfo() {
            cout << "Book Title: "; getline(cin >> ws, title); 
            cout << "Author: "; getline(cin >> ws, author);
            cout << "ISBN: "; getline(cin >> ws, ISBN);
        };
};

int main () {
    
}