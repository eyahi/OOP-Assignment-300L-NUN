#include <iostream>
#include <string>

#include "book.h"
#include "book_item.h"
#include "library_item.h"
#include "library.h"
#include "patron.h"
#include "patron_record.h"

int main() {
    // Create a Library
    Library myLibrary;

    // Created books
    BookItem book1("Object Oriented Programming", "Abdulfattah Abdulsalam", "211203010");
    BookItem book2("Murder On Orient Express", "Agatha Christie", "123456789");

    //adding books to library
    myLibrary.addBook(book1);
    myLibrary.addBook(book2);

    //adding a patron
    myLibrary.addPatron(PatronRecord("Dr. Ali Emmanuel", "0123456789"));
    myLibrary.addPatron(PatronRecord("Abdulfattah Abdulsalam", "16-01-24"));

    //borrowing a book
    myLibrary.borrowBook(book1, PatronRecord("Dr. Ali Emmanuel", "0123456789"));
    myLibrary.borrowBook(book2, PatronRecord("Abdulfattah Abdulsalam", "211203010"));

    //returning a book
    myLibrary.returnBook(book1, PatronRecord("Dr. Ali Emmanuel", "0123456789"));
    myLibrary.returnBook(book2, PatronRecord("Abdulfattah Abdulsalam", "211203010"));

    return 0;
}