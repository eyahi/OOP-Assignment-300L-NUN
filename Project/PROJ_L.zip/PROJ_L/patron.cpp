#include <iostream>
using namespace std;

class Patron {
    public:
        string name;
        string libraryCardNumber;

        Patron (string Name, string LibraryCardNumber) : name(Name), libraryCardNumber(LibraryCardNumber){}
         void getInfo() const {
            cout << "Name: " << name << endl << "Library Card Number: " << libraryCardNumber << endl; 
        }

        void setInfo() {
            cout << "Name: ";
            getline(cin >> ws, name); 
            cout << "Library Card Number: "; getline(cin >> ws, libraryCardNumber);
        };
};

int main(){

} 