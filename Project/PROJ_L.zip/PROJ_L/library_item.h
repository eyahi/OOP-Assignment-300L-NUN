#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H
#include <iostream>
using namespace std;
class LibraryItem{
protected:
    string title;
    bool isCheckedOut;
    string dueDate;
public:
    LibraryItem(string Title,bool IsCheckedOut,string DueDate): 
        title(Title), isCheckedOut(IsCheckedOut), dueDate(DueDate) {};
        
    bool getCheckedOut();
    string getDueDate();
    void setInfo( string Title, bool IsCheckedOut,string DueDate);
    void checkOut();
    void returnItem();
};
#endif
