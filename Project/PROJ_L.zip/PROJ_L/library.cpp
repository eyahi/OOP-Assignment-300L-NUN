#include "library.h"
#include<iostream>
using namespace std;
#include <vector>

class Patron; 

class Library {
private:
    vector<BookItem> books;
    vector<Patron> patrons;
    vector<PatronRecord> patronRecords;

public:
    void addBook(const string& title, const string& author, const string& isbn) {cout << "Book Successfully added." << endl;};;
    void addPatron(const string& name, int libraryCardNumber) {cout << "Patron Successfully added." << endl;};;
    BookItem* findBookByTitle(const string& title);
    Patron* findPatronByCardNumber(int libraryCardNumber);
    void borrowBook(const string& title, int libraryCardNumber) {cout << "Book Successfully borrowed." << endl;};
    void returnBook(const string& title, int libraryCardNumber) {cout << "Book Successfully returned." << endl;};
    void displayCheckedOutBooks(int libraryCardNumber) const;
};