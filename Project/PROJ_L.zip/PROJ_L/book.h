#include <iostream>
#ifndef BOOK_H
#define BOOK_H
using namespace std;
class Book{
    string title;
    string author;
    string ISBN;
    public:
    Book(string Title,string Author, string _ISBN);
    void getInfo(string Title,string Author,string _ISBN);
    void setInfo(string Title, string Author, string _ISBN);

};
#endif