#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include <string>

class Book {
private:
    std::string Title;
    std::string Author;
    int ISBN;

public:
    // Constructors
    Book(std::string title, std::string author, int isbn);

    // Getter methods to access private data
    std::string getTitle() const;
    std::string getAuthor() const;
    int getISBN() const;

    // Setter methods to modify private data
    void setTitle(const std::string& newTitle);
    void setAuthor(const std::string& newAuthor);
    void setISBN(int newISBN);

};

#endif
