
#ifndef LIBRARY_H
#define LIBRARY_H

#include <vector>
#include "BookItem.h"
#include "Patron.h"
#include "PatronRecord.h"
#include <limits> 
#include <cstddef>

class Library {
private:
    std::vector<BookItem> books;
    std::vector<Patron> patrons;
    std::vector<PatronRecord> patronRecords;

public:
    void addBook(const BookItem& book);
    void addPatron(const Patron& patron);
    void borrowBook(const Patron& patron, const BookItem& book, const std::string& dueDate);
    void returnBook(const Patron& patron, const BookItem& book);
    const PatronRecord& getPatronRecord(const Patron& patron) const;
    const std::vector<BookItem>& getBooks() const;

private:
    size_t getPatronIndex(const Patron& patron) const;
    size_t getBookIndex(const BookItem& book) const;
};

#endif