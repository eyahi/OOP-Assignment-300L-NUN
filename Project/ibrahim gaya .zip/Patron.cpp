#include "Patron.h"
#include <iostream>

Patron::Patron(std::string name, std::string libraryCardNumber)
    : Name(name), LibraryCardNumber(libraryCardNumber) {
}

std::string Patron::getName() const {
    return Name;
}

std::string Patron::getLibraryCardNumber() const {
    return LibraryCardNumber;
}

void Patron::setName(const std::string& newName) {
    Name = newName;
}

// Equality operator for Patron
bool Patron::operator==(const Patron& other) const {
    return Name == other.Name && LibraryCardNumber == other.LibraryCardNumber;
}

void Patron::setLibraryCardNumber(const std::string& newLibraryCardNumber) {
    LibraryCardNumber = newLibraryCardNumber;
}

// Display information
void Patron::displayInfo() {
    std::cout << "Name of Patron: " << Name << std::endl;
    std::cout << "Library Card Number: " << LibraryCardNumber << std::endl;
}
