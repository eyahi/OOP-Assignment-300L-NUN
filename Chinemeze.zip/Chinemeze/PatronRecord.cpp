#include "PatronRecord.h"
#include <vector>

void PatronRecord::addBook(const BookItem& book) {
    checkedOutBooks.push_back(book);
}

void PatronRecord::removeBook(const BookItem& book) {
    for (size_t i = 0; i < checkedOutBooks.size(); ++i) {
        if (checkedOutBooks[i] == book) {
            checkedOutBooks.erase(checkedOutBooks.begin() + i);
            break;
        }
    }
}

const std::vector<BookItem>& PatronRecord::getCheckedOutBooks() const {
    return checkedOutBooks;
}
