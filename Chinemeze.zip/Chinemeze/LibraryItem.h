#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <string>

class LibraryItem {
private:
    std::string Title;
    bool IsCheckedOut;
    std::string DueDate;

public:
    LibraryItem(std::string title, bool ischeckedout, std::string duedate);

    std::string getTitle() const;
    bool getIsCheckedOut() const;
    std::string getDueDate() const;
    void setTitle(const std::string& newTitle);
    void setIsCheckedOut(bool newIsCheckedOut);
    void setDueDate(const std::string& newDueDate);
    
    void checkOut(const std::string& dueDate);
    void returnItem();
};
#endif
