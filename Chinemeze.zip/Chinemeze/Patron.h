#ifndef PATRON_H
#define PATRON_H

#include <iostream>
#include <string>

class Patron {
private:
    std::string Name;
    std::string LibraryCardNumber;

public:
    Patron(std::string name, std::string libraryCardNumber);

    std::string getName() const;
    std::string getLibraryCardNumber() const;

    void setName(const std::string& newName);
    void setLibraryCardNumber(const std::string& newLibraryCardNumber);

    bool operator==(const Patron& other) const;

    void displayInfo();
};
#endif
